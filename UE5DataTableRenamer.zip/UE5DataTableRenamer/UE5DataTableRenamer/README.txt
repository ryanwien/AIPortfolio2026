================================================================================
 ASSET RENAMER — README
 Unreal Engine Python Tool
================================================================================

OVERVIEW
--------
Asset Renamer is a Python script that automatically renames assets in your
Unreal Engine project according to a naming convention defined in a Data Table.
It scans your content directory, matches each asset's class against your rules,
and renames anything that is missing its correct prefix (e.g. SM_, BP_, T_).


--------------------------------------------------------------------------------
INSTALLATION
--------------------------------------------------------------------------------

1. Copy asset_renamer.py into your project's Python Startup folder.

   In the Unreal Editor, open:

       Edit > Project Settings > Plugins > Python > Startup Scripts [0]

   Place the file at the path shown in that first startup slot, or add the
   path to asset_renamer.py directly into the [0] entry field.

2. The script will now run automatically every time the Editor starts.
   To trigger it manually at any time, open the Python console and run:

       import asset_renamer
       asset_renamer.run_asset_renamer()


--------------------------------------------------------------------------------
CONFIGURATION
--------------------------------------------------------------------------------

All settings are controlled by the RenameConfig dataclass at the top of the
script. You can edit the defaults directly, or pass a custom config when
calling run_asset_renamer().

  dt_asset_name   The bare name of your rename-rules Data Table.
                  Default: "DT_RenameRules"
                  The script finds the table automatically via the Asset
                  Registry, so it does not matter where in your project
                  the table lives.

  working_path    The root content folder to scan recursively.
                  Default: "/Game"

  dry_run         Set to True to preview all intended renames in the Output
                  Log without touching any files.
                  Default: False

  skip_paths      A list of content folders that will never be renamed.
                  Add any utility, developer, or plugin folders here.
                  Default: ["/Game/Blueprint/AssetRenamer", "/Game/Developers"]

Example — running with a custom config:

    from asset_renamer import run_asset_renamer, RenameConfig

    run_asset_renamer(RenameConfig(
        working_path = "/Game/Characters",
        dry_run      = True,
    ))


--------------------------------------------------------------------------------
DATA TABLE SETUP
--------------------------------------------------------------------------------

Create a Data Table asset in your project with the following row structure:

    Column Name       Type
    ---------------   ------
    AssetClassName    Name
    Prefix            String

Example rows:

    AssetClassName    Prefix
    --------------    ------
    Blueprint         BP_
    StaticMesh        SM_
    SkeletalMesh      SK_
    Texture2D         T_
    Material          M_
    MaterialInstance  MI_
    SoundWave         S_
    NiagaraSystem     NS_
    AnimSequence      AS_

Name the asset DT_RenameRules (or update dt_asset_name in RenameConfig to
match whatever name you choose).


--------------------------------------------------------------------------------
HOW IT WORKS
--------------------------------------------------------------------------------

The tool runs five steps in sequence:

  1. load_rule_map           Finds the Data Table via the Asset Registry and
                             builds the AssetClassName -> Prefix lookup.

  2. build_rename_plan       Scans all assets under working_path and queues
                             any asset whose name is missing the correct prefix.
                             A progress bar is shown with a Cancel button.

  3. check_rename_collisions Runs two safety passes before any file is touched:

                               Pass 1 — On-disk collision
                               Blocks any rename whose target name already
                               exists in the same folder.

                               Pass 2 — Intra-batch collision
                               Blocks any group of assets that would all
                               resolve to the same target name within the
                               same run.

  4. execute_renames         Renames all assets that cleared both checks,
                             with a second progress bar and Cancel button.

  5. log_summary             Prints a final count of renamed, blocked, and
                             failed assets to the Output Log.


--------------------------------------------------------------------------------
OUTPUT LOG
--------------------------------------------------------------------------------

All activity is written to the Unreal Output Log under the [Renamer] prefix.
To view it, open:  Window > Output Log

Example output:

    [Renamer] Located Data Table at: /Game/Blueprint/AssetRenamer/DT_RenameRules
    [Renamer] Rules loaded (6): Blueprint, StaticMesh, Texture2D, ...
    [Renamer] Scanning 214 asset(s) under '/Game'...
    [Renamer] 18 asset(s) queued for renaming.
    [Renamer] 1 asset(s) blocked by collision check:
      x Cube -- On-disk collision: 'SM_Cube' already exists in the target folder.
    [Renamer] 17 asset(s) cleared to rename.
    [Renamer] SM_RockA -> already correct, skipped
    [Renamer] Cube_Old -> SM_Cube_Old  (StaticMesh)
    ...
    [Renamer] Done.  Renamed: 17  |  Blocked: 1  |  Failed: 0


--------------------------------------------------------------------------------
REQUIREMENTS
--------------------------------------------------------------------------------

  - Unreal Engine 5.0 or later
  - Python plugin enabled  (Edit > Plugins > Python Editor Script Plugin)
  - Editor Scripting Utilities plugin enabled


================================================================================
