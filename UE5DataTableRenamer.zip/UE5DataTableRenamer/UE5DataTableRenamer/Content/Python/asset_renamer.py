import time
import unreal
from collections import defaultdict
from dataclasses import dataclass, field


# =============================================================================
# Asset Renamer : Driven by a UE Data Table of rename rules.
#
# Step functions called in order by run_asset_renamer:
#   1. load_rule_map           : locate the Data Table via the Asset Registry,
#                                then parse it into a class -> prefix dict.
#   2. build_rename_plan       : scan all assets and build the list of pending renames.
#   3. check_rename_collisions : split the plan into safe / blocked sets.
#   4. execute_renames         : apply the safe renames with a progress bar.
#   5. log_summary             : print the final counts to the Output Log.
# =============================================================================


# =============================================================================
# LOGGING HELPERS
# =============================================================================

_TAG = "[Renamer]"

def _log(msg: str)  -> None: unreal.log(f"{_TAG} {msg}")
def _warn(msg: str) -> None: unreal.log_warning(f"{_TAG} {msg}")
def _err(msg: str)  -> None: unreal.log_error(f"{_TAG} {msg}")

def _step(n: int, label: str) -> None:
    """Print a clearly visible step banner to the Output Log."""
    _log(f"--- Step {n}/5 : {label} ---")

def _divider() -> None:
    _log("=" * 56)


# =============================================================================
# CONFIGURATION
# =============================================================================

@dataclass
class RenameConfig:
    """
    All tunable parameters for a single rename pass.

    dt_asset_name : Bare name of the rename-rules Data Table. The full path is
                    resolved at runtime via the Asset Registry, so the table can
                    be moved freely without breaking this script.
    working_path  : Root content path to scan recursively.
    dry_run       : When True, log intended renames but do not touch any files.
    skip_paths    : Sub-paths that are never renamed (utility assets, dev folders).
    verbose       : When True, log every skipped asset and the reason it was skipped.
    """
    dt_asset_name : str       = "DT_RenameRules"
    working_path  : str       = "/Game"
    dry_run       : bool      = False
    verbose       : bool      = False
    skip_paths    : list[str] = field(default_factory=lambda: [
        "/Game/Blueprint/AssetRenamer",
        "/Game/Developers",
    ])

    def log_active_settings(self) -> None:
        """Print the active configuration to the Output Log for verification."""
        _log(f"  dt_asset_name : {self.dt_asset_name}")
        _log(f"  working_path  : {self.working_path}")
        _log(f"  dry_run       : {self.dry_run}")
        _log(f"  verbose       : {self.verbose}")
        _log(f"  skip_paths    : {self.skip_paths}")


# =============================================================================
# DATA MODEL
# =============================================================================

@dataclass
class RenameEntry:
    """Represents a single pending asset rename."""
    source_path  : str
    new_path     : str
    current_name : str
    new_name     : str
    asset_class  : str
    blocked      : bool = False
    reason       : str  = ""


@dataclass
class RenameStats:
    """Accumulated outcome counts for a completed rename pass."""
    renamed : int = 0
    blocked : int = 0
    failed  : int = 0

    def record_blocked(self, count: int) -> None:
        self.blocked += count

    def record_renamed(self) -> None:
        self.renamed += 1

    def record_failed(self) -> None:
        self.failed += 1


# =============================================================================
# STEP 1 : Locate and load the rename rule map from the Data Table
# =============================================================================

def _find_data_table(dt_asset_name: str) -> unreal.DataTable | None:
    """
    Use the Asset Registry to locate dt_asset_name anywhere in the project.
    Returns the loaded DataTable object, or None if it cannot be found.

    UE 5.7.4 compatibility notes:
      - ARFilter no longer accepts 'asset_names'; filter by name manually instead.
      - AssetRegistryHelpers.get_asset() is deprecated; use asset_data.get_asset().
      - class_paths requires unreal.TopLevelAssetPath structs, not plain strings.
    """
    _log(f"Searching Asset Registry for DataTable '{dt_asset_name}'...")

    ar        = unreal.AssetRegistryHelpers.get_asset_registry()
    ar_filter = unreal.ARFilter(
        class_paths     = [unreal.TopLevelAssetPath("/Script/Engine", "DataTable")],
        recursive_paths = True,
        package_paths   = ["/Game"],
    )
    all_results = ar.get_assets(ar_filter)

    # 'asset_names' kwarg removed in UE5.1+; match by name in Python instead.
    results = [r for r in all_results if str(r.asset_name) == dt_asset_name]

    if not results:
        _err(f"Could not find a DataTable named '{dt_asset_name}' anywhere under /Game.")
        return None

    if len(results) > 1:
        paths = ", ".join(str(r.package_name) for r in results)
        _warn(f"Found {len(results)} DataTables named '{dt_asset_name}': {paths}. Using the first result.")

    asset_data = results[0]
    _log(f"Located Data Table at: {asset_data.package_name}")

    # AssetRegistryHelpers.get_asset() deprecated in UE5.5+; call on the data object directly.
    return asset_data.get_asset()


def load_rule_map(config: RenameConfig) -> dict[str, str]:
    """
    Locate the Data Table via the Asset Registry and return a dict
    mapping AssetClassName -> Prefix.
    Returns an empty dict and logs an error if anything is invalid.
    """
    dt_asset = _find_data_table(config.dt_asset_name)
    if not dt_asset:
        return {}

    get_col     = unreal.DataTableFunctionLibrary.get_data_table_column_as_string
    class_names = get_col(dt_asset, "AssetClassName")
    prefixes    = get_col(dt_asset, "Prefix")

    if not class_names or not prefixes:
        _err("Data Table columns 'AssetClassName' or 'Prefix' are empty.")
        return {}

    if len(class_names) != len(prefixes):
        _err(f"Column length mismatch: {len(class_names)} class names vs {len(prefixes)} prefixes.")
        return {}

    rule_map = dict(zip(class_names, prefixes))
    _log(f"Rules loaded ({len(rule_map)}): {', '.join(rule_map.keys())}")

    if config.verbose:
        for cls, prefix in rule_map.items():
            _log(f"  {cls:30s} -> '{prefix}'")

    return rule_map

# =============================================================================
# STEP 2 : Scan all assets and build the rename plan
# =============================================================================

def _is_protected(asset_path: str, skip_paths: list[str]) -> bool:
    """Return True if the asset lives inside a protected directory."""
    return any(asset_path.startswith(skip) for skip in skip_paths)


def build_rename_plan(
    rule_map : dict[str, str],
    config   : RenameConfig,
) -> list[RenameEntry] | None:
    """
    Scan every asset under config.working_path and build the list of intended renames.

    Returns None if the user cancels the scan, or an empty list if no assets
    matched the rename rules.
    """
    all_asset_paths = unreal.EditorAssetLibrary.list_assets(config.working_path, recursive=True)
    total           = len(all_asset_paths)
    _log(f"Scanning {total} asset(s) under '{config.working_path}'...")

    plan    : list[RenameEntry] = []
    skipped : int               = 0

    with unreal.ScopedSlowTask(total, "Scanning assets...") as scan_task:
        scan_task.make_dialog(True)

        for asset_path in all_asset_paths:
            if scan_task.should_cancel():
                _warn("Scan cancelled by user.")
                return None
            scan_task.enter_progress_frame(1, asset_path)

            if _is_protected(asset_path, config.skip_paths):
                if config.verbose:
                    _log(f"  SKIP (protected path)  : {asset_path}")
                skipped += 1
                continue

            asset_data = unreal.EditorAssetLibrary.find_asset_data(asset_path)
            if not asset_data.is_valid():
                if config.verbose:
                    _warn(f"  SKIP (invalid metadata): {asset_path}")
                skipped += 1
                continue

            current_class = str(asset_data.asset_class_path.asset_name)
            current_name  = str(asset_data.asset_name)
            prefix        = rule_map.get(current_class)

            if not prefix:
                if config.verbose:
                    _log(f"  SKIP (no rule)         : {current_name}  [{current_class}]")
                continue

            if current_name.startswith(prefix):
                if config.verbose:
                    _log(f"  SKIP (already prefixed): {current_name}  [{current_class}]")
                continue

            new_name  = f"{prefix}{current_name}"
            asset_dir = unreal.Paths.get_path(asset_path)

            plan.append(RenameEntry(
                source_path  = asset_path,
                new_path     = f"{asset_dir}/{new_name}",
                current_name = current_name,
                new_name     = new_name,
                asset_class  = current_class,
            ))

            if config.verbose:
                _log(f"  QUEUED                 : {current_name} -> {new_name}  [{current_class}]")

    _log(f"Scan complete. Queued: {len(plan)}  |  Skipped: {skipped}")
    return plan

# =============================================================================
# STEP 3 : Pre-flight collision check
# =============================================================================

def _block_disk_collisions(
    entries : list[RenameEntry],
    verbose : bool,
) -> tuple[list[RenameEntry], list[RenameEntry]]:
    """
    Pass 1: block any entry whose target path already exists on disk.
    Returns (survivors, newly_blocked).
    """
    survivors : list[RenameEntry] = []
    blocked   : list[RenameEntry] = []

    with unreal.ScopedSlowTask(len(entries), "Checking for disk collisions...") as disk_task:
        disk_task.make_dialog(True)

        for entry in entries:
            disk_task.enter_progress_frame(1, entry.new_path)

            if unreal.EditorAssetLibrary.does_asset_exist(entry.new_path):
                entry.blocked = True
                entry.reason  = f"On-disk collision: '{entry.new_name}' already exists in the target folder."
                blocked.append(entry)
                if verbose:
                    _warn(f"  DISK COLLISION: {entry.current_name} -> {entry.new_name}")
            else:
                survivors.append(entry)

    _log(f"Disk collision pass complete. Survivors: {len(survivors)}  |  Blocked: {len(blocked)}")
    return survivors, blocked


def _block_batch_collisions(
    entries : list[RenameEntry],
    verbose : bool,
) -> tuple[list[RenameEntry], list[RenameEntry]]:
    """
    Pass 2: block any group of entries that would all rename to the same path.
    Returns (safe, newly_blocked).
    """
    target_map : dict[str, list[RenameEntry]] = defaultdict(list)
    for entry in entries:
        target_map[entry.new_path].append(entry)

    safe    : list[RenameEntry] = []
    blocked : list[RenameEntry] = []

    with unreal.ScopedSlowTask(len(target_map), "Checking for batch collisions...") as batch_task:
        batch_task.make_dialog(True)

        for competing in target_map.values():
            batch_task.enter_progress_frame(1, competing[0].new_name)

            if len(competing) == 1:
                safe.append(competing[0])
            else:
                source_names = ", ".join(e.current_name for e in competing)
                for entry in competing:
                    entry.blocked = True
                    entry.reason  = (
                        f"Intra-batch collision: [{source_names}] would all "
                        f"rename to '{entry.new_name}' in the same folder."
                    )
                    blocked.append(entry)
                if verbose:
                    _warn(f"  BATCH COLLISION: [{source_names}] all target '{competing[0].new_name}'")

    _log(f"Batch collision pass complete. Safe: {len(safe)}  |  Blocked: {len(blocked)}")
    return safe, blocked


def check_rename_collisions(
    plan    : list[RenameEntry],
    config  : RenameConfig,
) -> tuple[list[RenameEntry], list[RenameEntry]]:
    """
    Run both collision passes and return (safe, blocked).
    Logs a warning for every blocked entry.
    """
    survivors, disk_blocked  = _block_disk_collisions(plan, config.verbose)
    safe,      batch_blocked = _block_batch_collisions(survivors, config.verbose)
    blocked                  = disk_blocked + batch_blocked

    if blocked:
        _warn(f"{len(blocked)} asset(s) blocked — details:")
        for entry in blocked:
            _warn(f"  x {entry.current_name} -- {entry.reason}")

    _log(f"{len(safe)} asset(s) cleared to rename.")
    return safe, blocked


# =============================================================================
# STEP 4 : Execute the safe renames
# =============================================================================

def execute_renames(
    safe   : list[RenameEntry],
    config : RenameConfig,
    stats  : RenameStats,
) -> None:
    """
    Rename every asset in safe, writing results into stats.
    Shows a cancellable progress bar.
    """
    with unreal.ScopedSlowTask(len(safe), "Renaming assets...") as rename_task:
        rename_task.make_dialog(True)

        for entry in safe:
            if rename_task.should_cancel():
                _warn("Rename cancelled by user.")
                break
            rename_task.enter_progress_frame(1, entry.source_path)

            tag = "[DRY RUN] " if config.dry_run else ""
            _log(f"{tag}{entry.current_name} -> {entry.new_name}  ({entry.asset_class})")

            if config.dry_run:
                stats.record_renamed()
                continue

            if unreal.EditorAssetLibrary.rename_asset(entry.source_path, entry.new_path):
                stats.record_renamed()
            else:
                _warn(f"Failed to rename '{entry.current_name}'. Asset may be locked or referenced by an unsaved map.")
                stats.record_failed()


# =============================================================================
# STEP 5 : Print the final summary
# =============================================================================

def log_summary(stats: RenameStats, config: RenameConfig, elapsed: float) -> None:
    """Print a formatted summary of the rename pass to the Output Log."""
    _divider()
    _log(f"  Renamed : {stats.renamed}")
    _log(f"  Blocked : {stats.blocked}")
    _log(f"  Failed  : {stats.failed}")
    _log(f"  Time    : {elapsed:.2f}s")
    if config.dry_run:
        _log("  Re-run with dry_run=False to apply changes.")
    _divider()


# =============================================================================
# ENTRY POINT
# =============================================================================

def run_asset_renamer(config: RenameConfig = RenameConfig()) -> None:
    """Orchestrate the full rename pass by calling each step in order."""
    start = time.time()

    _divider()
    _log("Starting asset rename pass")
    if config.dry_run:
        _log("*** DRY RUN — no files will be modified ***")
    config.log_active_settings()
    _divider()

    # Step 1 : Load rules
    _step(1, "Load rule map")
    rule_map = load_rule_map(config)
    if not rule_map:
        _err("No rules loaded. Aborting.")
        return

    # Step 2 : Build plan
    _step(2, "Build rename plan")
    plan = build_rename_plan(rule_map, config)
    if plan is None:
        return
    if not plan:
        _log("No assets matched the rename rules. Exiting.")
        return

    # Step 3 : Collision check
    _step(3, "Collision check")
    safe, blocked = check_rename_collisions(plan, config)
    if not safe:
        _log("Nothing safe to rename. Exiting.")
        stats = RenameStats(blocked=len(blocked))
        log_summary(stats, config, time.time() - start)
        return

    # Step 4 : Execute
    _step(4, "Execute renames")
    stats = RenameStats(blocked=len(blocked))
    execute_renames(safe, config, stats)

    # Step 5 : Summary
    _step(5, "Summary")
    log_summary(stats, config, time.time() - start)


run_asset_renamer()